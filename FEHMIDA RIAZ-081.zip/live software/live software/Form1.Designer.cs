﻿namespace live_software
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnlogin = new Button();
            label1 = new Label();
            label2 = new Label();
            txtpass = new TextBox();
            txtuser = new TextBox();
            btnexit = new Button();
            btnreset = new Button();
            label3 = new Label();
            SuspendLayout();
            // 
            // btnlogin
            // 
            btnlogin.Location = new Point(348, 254);
            btnlogin.Name = "btnlogin";
            btnlogin.Size = new Size(75, 23);
            btnlogin.TabIndex = 0;
            btnlogin.Text = "login";
            btnlogin.UseVisualStyleBackColor = true;
            btnlogin.Click += btnlogin_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BorderStyle = BorderStyle.Fixed3D;
            label1.Location = new Point(348, 98);
            label1.Name = "label1";
            label1.Size = new Size(61, 17);
            label1.TabIndex = 1;
            label1.Text = "username";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BorderStyle = BorderStyle.Fixed3D;
            label2.Location = new Point(348, 150);
            label2.Name = "label2";
            label2.Size = new Size(59, 17);
            label2.TabIndex = 2;
            label2.Text = "password";
            // 
            // txtpass
            // 
            txtpass.Location = new Point(460, 144);
            txtpass.Name = "txtpass";
            txtpass.Size = new Size(142, 23);
            txtpass.TabIndex = 3;
            // 
            // txtuser
            // 
            txtuser.ForeColor = SystemColors.InactiveCaptionText;
            txtuser.Location = new Point(460, 92);
            txtuser.Name = "txtuser";
            txtuser.Size = new Size(142, 23);
            txtuser.TabIndex = 4;
            // 
            // btnexit
            // 
            btnexit.Location = new Point(561, 254);
            btnexit.Name = "btnexit";
            btnexit.Size = new Size(75, 23);
            btnexit.TabIndex = 5;
            btnexit.Text = "exit";
            btnexit.UseVisualStyleBackColor = true;
            btnexit.Click += btnexit_Click;
            // 
            // btnreset
            // 
            btnreset.Location = new Point(460, 254);
            btnreset.Name = "btnreset";
            btnreset.Size = new Size(75, 23);
            btnreset.TabIndex = 6;
            btnreset.Text = "reset";
            btnreset.UseVisualStyleBackColor = true;
            btnreset.Click += btnreset_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BorderStyle = BorderStyle.Fixed3D;
            label3.Location = new Point(409, 22);
            label3.Name = "label3";
            label3.Size = new Size(47, 17);
            label3.TabIndex = 7;
            label3.Text = "LOGIN ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.WindowFrame;
            ClientSize = new Size(808, 450);
            Controls.Add(label3);
            Controls.Add(btnreset);
            Controls.Add(btnexit);
            Controls.Add(txtuser);
            Controls.Add(txtpass);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnlogin);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnlogin;
        private Label label1;
        private Label label2;
        private TextBox txtpass;
        private TextBox txtuser;
        private Button btnexit;
        private Button btnreset;
        private Label label3;
    }
}
