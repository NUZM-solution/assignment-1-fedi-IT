namespace live_software
{
    public partial class Form1 : Form
    {
        double count = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void frmlogin_Load(object sender, EventArgs e)
        {
            this.AcceptButton = btnlogin;
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string user, pass;
            user = txtuser.Text;
            pass = txtpass.Text;

            if (user == "Fehmida_Riaz" && pass == "22011556-081")
            {
                MessageBox.Show("Welcome fehmida");
            }
            else
            {
                count += 1;
                double maxcount = 3;
                double remain = maxcount - count;

                MessageBox.Show("Wrong username or password" + "\t" + remain + " tries left");
                txtpass.Clear();
                txtuser.Clear();
                txtuser.Focus();

                if (count == maxcount)
                {
                    MessageBox.Show("Max tries exceeded.");
                    Application.Exit();
                }
            }
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtpass.Clear();
            txtuser.Clear();
            txtuser.Focus();
        }
    }
}
